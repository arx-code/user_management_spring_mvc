package User_Management_System.user_mgt_sys.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import User_Management_System.user_mgt_sys.Dao.UserLogin;
import User_Management_System.user_mgt_sys.model.User;
import User_Management_System.user_mgt_sys.service.UserService;


@org.springframework.stereotype.Controller
public class Controller {
	
	User cruntUser;
	
	@Autowired
	UserService service;
	
	@RequestMapping("/")
	public String home() {
		
		return"home";
	}
	
	

	@GetMapping("/open-registrationPage")
	public String openRegistrationPage() {
		return "userRegistration";
	}
	
	@PostMapping("/register-user")
	public String userRegestration(@ModelAttribute User user, Model m) {
		System.out.println("User Details >> /n"+ user);
		String msg;
		User dbUser= service.getUser(user.getUserName());
		if (dbUser != null && dbUser.getUserName().equals(user.getUserName())) {
	        msg = "Username already taken. Please try another.";
	        m.addAttribute("msg", msg);
	        return "userRegistration";
	    } else {
	        msg = service.setUser(user);
	        m.addAttribute("user", user);
	        return "WelcomePage";
	    }		
	}
	
	
	

	@GetMapping("/user-loginPage")
	public String openUserLogin() {
		return "login";
	}
	
	@PostMapping("/verify-LoginDetails")
	public String verifyLoginDetails(@ModelAttribute User user, Model model) {
		System.out.println("User Login Details >>>>");
		
		String msg =service.verifyUser(user.getUserName(),user.getPswd());
		model.addAttribute("msg", msg);
		
		
		User dbUser = service.getUser(user.getUserName());
		cruntUser = service.getUser(user.getUserName());
		
		
		model.addAttribute(dbUser);
		
		model.addAttribute("name", dbUser.getName());
		return "WelcomePage";
	}
	
	@GetMapping("/view-user")
	public String viewUser(Model model) {
	    User user = service.getUser("amer");
	    model.addAttribute("user", user); 
		return "viewPage";
	}
	
	
	@GetMapping("/get-AllUser")
	public String viewAllUser(Model model) {
		List<User> userList = new ArrayList<User>();
		userList = service.getAllUser();
		model.addAttribute("userList", userList); 
		for(User u:userList) {
			System.out.println(u);
		}
		return "viewAllUserPage";
	}
	
	
	@PostMapping("/get-user")
	public String getUser(@RequestParam String userName, Model model) {
		User dbUser = service.getUser(userName);
		
		
		model.addAttribute(dbUser);
		return "viewPage";
	}
	

	@GetMapping("/log-out")
	public String logOut(Model model) {
		if(cruntUser!=null) {
			model.addAttribute("name", cruntUser.getName());
			return"logout";
		}
		
		User dbUser = service.getUser("amer");
		model.addAttribute("name", dbUser.getName());
		
		return "logout";
	}

	
}

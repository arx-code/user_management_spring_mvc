package User_Management_System.user_mgt_sys.model;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class User {
	
	@Id
	String userName;
	String name;
	String address;
	String pswd;
	
	
	
	
	public String getUserName() {
		return userName;
	}




	public void setUserName(String userName) {
		this.userName = userName;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getPswd() {
		return pswd;
	}




	public void setPswd(String pswd) {
		this.pswd = pswd;
	}




	@Override
	public String toString() {
		return "User [userName=" + userName + ", name=" + name + ", address=" + address + ", pswd=" + pswd + "]";
	}

	
}

package User_Management_System.user_mgt_sys.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import User_Management_System.user_mgt_sys.Dao.Dao;
import User_Management_System.user_mgt_sys.model.User;

@Service
public class UserService {

	@Autowired
	Dao dao;
	
	public String setUser(User user) {
		String msg= "some thing went worng";
		
		User dbUser = dao.getUser(user.getUserName());

		 msg = dao.setUser(user);

		return msg;
	}
	
	
	

	public String verifyUser(String name, String pswd) {
	
		User dbUser = dao.getUser(name);
		if (dbUser == null) {
			return "User not found";
		}
		else if(!dbUser.getPswd().equals(pswd)) {
			System.out.println("user Match ");
			return "Incorrect password";
		}
			return "User authenticated successfully";
		
	}


	public User getUser(String userName) {
		return dao.getUser(userName);
		
	}




	public List<User> getAllUser() {
		List<User> userList = dao.getAllUser();
		return userList;
	}
	


}

package User_Management_System.user_mgt_sys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserMgtSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMgtSysApplication.class, args);
		System.out.println("<---User Management System--->");
	}

}

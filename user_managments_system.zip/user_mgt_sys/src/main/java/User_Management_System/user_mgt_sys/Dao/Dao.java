package User_Management_System.user_mgt_sys.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zaxxer.hikari.util.ClockSource.Factory;

import User_Management_System.user_mgt_sys.model.User;


@Repository
public class Dao {
	

	@Autowired
	SessionFactory factory;
	
//	Session session = factory.openSession();
	
	
	public String setUser(User user) {
		String msg = "Somthing went worng";
		try {
			Session session = factory.openSession();
			session.save(user);
			session.beginTransaction().commit();
			msg ="User insered";
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			return msg;
	}

	public User getUser(String userName) {
		try {
			Session session = factory.openSession();
			User u1 = session.get(User.class, userName);
			return u1;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		return null;
	}

	public List<User> getAllUser() {
		Session session = factory.openSession();
		List<User> staffList = null;
        
        try {
            staffList = session.createQuery
            		("FROM User", User.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }

        return staffList;
	}
	
}

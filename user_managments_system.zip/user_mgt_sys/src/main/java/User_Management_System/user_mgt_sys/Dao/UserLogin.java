package User_Management_System.user_mgt_sys.Dao;



public class UserLogin {
	String userName;
	String pswd;
	public UserLogin(String userName, String pswd) {
		super();
		this.userName = userName;
		this.pswd = pswd;
	}
	public UserLogin() {
	
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	
	
	
	

}

package User_Management_System.user_mgt_sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMgtSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
